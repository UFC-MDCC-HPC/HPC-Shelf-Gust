/* AUTOMATICALLY GENERATE CODE */

using br.ufc.pargo.hpe.kinds;

namespace br.ufc.mdcc.model.Model { 

public interface BaseIModel : IDataStructureKind 
{



} // end main interface 

} // end namespace 
