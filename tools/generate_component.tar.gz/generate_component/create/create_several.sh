#!/bin/bash
./generate.sh br.ufc.mdcc.common Data
./generate.sh br.ufc.mdcc.common Platform
./generate.sh br.ufc.mdcc.common.graph Graph





